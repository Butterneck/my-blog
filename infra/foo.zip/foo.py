def handler(event, context):
    print(f"event: {event}\ncontext: {context}")